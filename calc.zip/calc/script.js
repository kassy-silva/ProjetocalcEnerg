let equipamentosSelecionados = [];
let equipamentoSelecionado = null;
let potenciaEquipamento = null;

function selecionarEquipamento(equipamento, potencia) {
    equipamentoSelecionado = equipamento;
    potenciaEquipamento = potencia;
    document.getElementById('resultado-individual').innerHTML = `Equipamento selecionado: ${equipamento} (Potência: ${potencia}W)`;
}

function calcularConsumo() {
    const tempoUso = parseFloat(document.getElementById('tempo_uso').value);
    const potencia = parseFloat(document.getElementById('potencia').value);
    const dias = parseInt(document.getElementById('dias').value);

    if (isNaN(tempoUso) || tempoUso <= 0 || isNaN(potencia) || potencia <= 0 || isNaN(dias) || dias <= 0 || !equipamentoSelecionado) {
        alert('Por favor, insira valores válidos para o tempo de uso, potência, número de dias e selecione um equipamento.');
        return;
    }

    // Calcular o consumo diário e mensal
    const consumoDiario = (potencia / 1000) * tempoUso;
    const consumoMensal = consumoDiario * dias; // Considerando dias no mês

    // Calcular o custo mensal
    const tarifa = 0.60; // Tarifa fixa para simplificação, você pode ajustar isso conforme necessário
    const custoMensal = consumoMensal * tarifa;

    // Exibir o resultado individual
    document.getElementById('resultado-individual').innerHTML = `
        Consumo Mensal do ${equipamentoSelecionado}: ${consumoMensal.toFixed(2)} kWh<br>
        Custo Mensal: R$ ${custoMensal.toFixed(2)}
    `;

    // Adicionar equipamento à lista de selecionados
    equipamentosSelecionados.push({
        quantidade: 1, // Considerando uma unidade por vez
        descricao: equipamentoSelecionado,
        usoDiario: tempoUso,
        kWhMes: consumoMensal.toFixed(2),
        custoMes: custoMensal.toFixed(2)
    });

    // Atualizar tabela
    atualizarTabela();

    // Limpar seleção
    limparSelecao();
}

function atualizarTabela() {
    const tabela = document.getElementById('tabela-total');
    tabela.innerHTML = ''; // Limpar tabela

    let consumoTotal = 0;
    let custoTotal = 0;

    equipamentosSelecionados.forEach(item => {
        consumoTotal += parseFloat(item.kWhMes);
        custoTotal += parseFloat(item.custoMes);

        const linha = document.createElement('tr');
        linha.innerHTML = `
            <td>${item.quantidade}</td>
            <td>${item.descricao}</td>
            <td>${item.usoDiario} Horas</td>
            <td>${item.kWhMes} kWh</td>
            <td>R$ ${item.custoMes}</td>
        `;
        tabela.appendChild(linha);
    });

    // Adicionar linha do total
    const linhaTotal = document.createElement('tr');
    linhaTotal.innerHTML = `
        <td colspan="3"><strong>Total</strong></td>
        <td><strong>${consumoTotal.toFixed(2)} kWh</strong></td>
        <td><strong>R$ ${custoTotal.toFixed(2)}</strong></td>
    `;
    tabela.appendChild(linhaTotal);
}

function limparSelecao() {
    equipamentoSelecionado = null;
    potenciaEquipamento = null;
    document.getElementById('tempo_uso').value = '';
    document.getElementById('potencia').value = '';
    document.getElementById('dias').value = '';
}

function mudarAmbiente() {
    const ambiente = document.getElementById('ambiente').value;
    // Redirecionar ou atualizar conteúdo com base no ambiente selecionado
    // Exemplo: location.href = ambiente + '.html';
}
